<?php


$y = 1;
do{
	
	$a = $y;
	$x = 0;
	do {
		echo ("\$product_name$a");
		echo "< br>";
		echo "<br>";
		$x++;
	} while ($x < 29);
	$y++;
} while ($y < 142);
?>