<div class="container">
	<div class="widget-header"><i class="icon-list-alt"></i><h3>List Tagihan Yamaha</h3>
</div>
<div class="widget-content">
	<div class="tab-content">
		<div id="listpengiriman" class="tab-pane active">
			<div><h3><a href="admin.php?page=addpengiriman&amp;&amp;sub=1">
            <img src="img/Button-Add-icon.png" width="30px" style="padding:5px;" />
            </a></h3></div>
			<?php include('listtagihanyamaha.php'); ?>
		</div>
	</div>
</div>