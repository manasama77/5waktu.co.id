<?php
include('config.php');

$id = $_REQUEST['id'];
$kueri = mysqli_query($con, "DELETE FROM tbl_class_pricelist WHERE id_class_pricelist = '$id'");

if($kueri)
{
	header("location:admin.php?page=configuration&&tab=cpl");
}
else
{
	echo("error");
}
?>