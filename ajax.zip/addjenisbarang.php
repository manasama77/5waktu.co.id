<div class="container">
<div class="widget-content">
<?php
include('config.php');
?>
<div id="formcontrols" class="tab-pane active">
	<form id="add-template" class="form-horizontal" action="prosesaddjenisbarang.php">
    	<fieldset>
        	<div class="control-group">
            	<label class="control-label" for="nama_barang">Jenis Barang</label>
              <div class="controls"><input name="nama_barang" class="text" id="nama_barang" Value=""></div>
            </div>
            <div class="form-actions">
            	<button class="btn btn-primary" type="submit">Save</button>
            </div>
    	</fieldset>
    </form>
</div>
</div>