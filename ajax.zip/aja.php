<link href="css/jquery-ui.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.js" type="text/javascript"></script>
<script>
$(function() {
	$( "#datepicker" ).datepicker();
});
</script>
<form>
    <label>Tanggal: </label>
    <input type="text" id="datepicker" />
</form> 