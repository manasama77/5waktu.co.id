<div class="container">
	<div class="widget-header"><i class="icon-list-alt"></i><h3>Product Price List</h3>
</div>
<div class="widget-content">
	<div class="tab-content">
		<div id="pricelist" class="tab-pane active">
			<?php include('productpricelist.php'); ?>
		</div>
	</div>
</div>