<?php
$connect_error = 'Sorry, we\'re experiencing connection issues.';
$con = mysqli_connect('localhost', 'h50505_mysqldb', '5waktu.co.id');
mysqli_select_db($con, 'h50505_lwldb') or die(mysqli_error($con));
?>