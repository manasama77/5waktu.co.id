<style>
	td{ font-size:12px; }
</style>
<div class="container">	
	<div class="widget-header">
		<i class="fa fa-list-alt"></i>
		<h3>Laporan Pengiriman - <font color="blue">All Data</font></h3>
	</div>
	<div class="widget-content">
		<div class="table-responsive">
			<table id="dashboardlist" width="100%" class="table table-responsive table-hover table-bordered">
				<thead>
					<tr>			
						<th style="text-align:center;">DO Num</th>
						<th style="text-align:center;">Warehouse</th>
						<th style="text-align:center;">DO Print Date</th>
						<th style="text-align:center;">Exit Date</th>
						<th style="text-align:center;">Estimation Date</th>
						<th style="text-align:center;">Delivered Date</th>
						<th style="text-align:center;">Dealer</th>
						<th style="text-align:center;">Total Cost (IDR)</th>
						<th style="text-align:center;">Status Delivery</th>
						<th style="text-align:center;">Delivery Late Time (Day)</th>
						<th style="text-align:center;">Received Name</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="text-align:center;">DO Num</td>
						<td style="text-align:center;">Warehouse</td>
						<td style="text-align:center;">DO Print Date</td>
						<td style="text-align:center;">Exit Date</td>
						<td style="text-align:center;">Estimation Date</td>
						<td style="text-align:center;">Delivered Date</td>
						<td style="text-align:center;">Dealer</td>
						<td style="text-align:center;">Total Cost (IDR)</td>
						<td style="text-align:center;">Status Delivery</td>
						<td style="text-align:center;">Delivery Late Time (Day)</td>
						<td style="text-align:center;">Received Name</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>

<div id="modalnyadash"></div>